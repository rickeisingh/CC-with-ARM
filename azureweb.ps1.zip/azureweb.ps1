﻿configuration mywebserver 
{
    param 
    (
        [Parameter(Mandatory=$true)]
        [String]$servername
        )
        node $servername 
        {
        WindowsFeature WEBSERVER
        {
        Name = Web-Server
        Ensure = "Present"
        IncludeAllSubFeature = $true
        }
    }
}

            
   