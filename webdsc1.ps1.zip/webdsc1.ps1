﻿Configuration IISInstall
{

param (
        [Parameter(Mandatory=$true)]
        [string]$machinename

        )
    node $machinename
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }
    }
}


