﻿configuration ADDS { 
    param ( 
        [Parameter(Mandatory)]
        [String] $DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $ccadmincreds,

        [Int]$Retry=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory 
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($ccadmincreds.UserName)", $ccadmincreds.Password)
   
    Node localhost {
        WindowsFeature ADDSInstall { 
            Ensure = 'Present' 
            Name = 'AD-Domain-Services'
        } 
        xWaitForADDomain ADForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $Retry 
            RetryIntervalSec = $RetryIntervalSec
        }  
        xADDomainController DomainController { 
            DomainName = $DomainName 
            DomainAdministratorCredential = $DomainCreds 
            SafemodeAdministratorPassword = $DomainCreds
        }
   }
}