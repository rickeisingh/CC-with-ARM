﻿configuration ADDS { 
    param ( 
        [Parameter(Mandatory)]
        [String] $DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $ccadmincreds,

    ) 
    
    Import-DscResource -ModuleName xActiveDirectory 
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($ccadmincreds.UserName)", $ccadmincreds.Password)
   
    Node localhost {
        WindowsFeature ADDSInstall { 
            Ensure = 'Present' 
            Name = 'AD-Domain-Services'
        } 
         
        xADDomainController DomainController { 
            DomainName = $DomainName 
            DomainAdministratorCredential = $DomainCreds 
            SafemodeAdministratorPassword = $DomainCreds
        }
   }
}