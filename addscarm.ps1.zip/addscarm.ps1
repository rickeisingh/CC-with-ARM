﻿configuration ADDS { 
    param ( 
        [Parameter(Mandatory)]
        [String] $DomainName,

        [Parameter(Mandatory)]
        [PSCredential] $ccadmincreds,

        [Parameter(Mandatory)]
        [string] $vmname

    ) 
    
    Import-DscResource -ModuleName xActiveDirectory 
    
    [PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName$($ccadmincreds.UserName)", $ccadmincreds.GetNetworkCredential().SecurePassword)
   
    Node $vmname {
        LocalConfigurationManager {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }  
        WindowsFeature ADDSInstall { 
            Ensure = 'Present' 
            Name = 'AD-Domain-Services'
        } 
         
        xADDomainController DomainController { 
            DomainName = $DomainName 
            DomainAdministratorCredential = $DomainCreds 
            SafemodeAdministratorPassword = $DomainCreds
        }
   }
}