﻿   param             
    (             
                    
        [Parameter(Mandatory)]            
        [string]$username,
        
        [Parameter(Mandatory=$true)]
        [string]$domain,
        
        [Parameter(Mandatory)]
        [string]$computername            
    )      

configuration adds             
{             
 
            
    Import-DscResource -ModuleName xActiveDirectory             
            
    Node $computername           
    {             
            
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }            
            
        File ADFiles            
        {            
            DestinationPath = 'c:\NTDS'            
            Type = 'Directory'            
            Ensure = 'Present'            
        }            
                    
        WindowsFeature ADDSInstall             
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"             
        }            
            
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }            
                        
        xADDomain FirstDS             
        {             
            DomainName = $domain             
            DomainAdministratorCredential = $InstallerServiceAccount             
            SafemodeAdministratorPassword = $InstallerServiceAccount                      
            DependsOn = "[WindowsFeature]ADDSInstall","[File]ADFiles"            
        }            
            
    }               
}

$SecurePassword = ConvertTo-SecureString -String "abab12UNI" -AsPlainText -Force
$InstallerServiceAccount = New-Object System.Management.Automation.PSCredential ('$username', $SecurePassword)          
            
# Config for ADDS              
$ConfigData = @{             
    AllNodes = @(             
        @{             
            Nodename = $computername                         
            DomainName = $domain            
            RetryCount = 20              
            RetryIntervalSec = 30            
            PsDscAllowPlainTextPassword = $true            
        }            
    )             
}             
            
ADDS -ConfigurationData $ConfigData           
            
# Make sure that LCM is set to continue configuration after reboot            
Set-DSCLocalConfigurationManager -Path .\ADDS –Verbose            
            
# Create the domain            
Start-DscConfiguration -Wait -Force -Path .\ADDS -Verbose   